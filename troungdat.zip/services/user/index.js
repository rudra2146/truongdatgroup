const userRoutes = require('./user.routes');


module.exports = userRoutes;
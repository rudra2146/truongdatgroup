const Home = require("./home.model");
const mongoose = require('mongoose');
const commonResponse = require('../../helper/commonResponse');

module.exports = {
    /**
     * Add
     */

    createHome: async (req, res, next) => {
        try {
            // Ensure image is uploaded
            if (!req.file) {
                return commonResponse.error(
                    res, 
                    "Error: carouselImg is required", // Updated error message for clarity
                    400, 
                    "CAROUSEL_IMG_REQUIRED" // Updated message code
                );
            }
    
            // Prepare home data object, including the image path
            const homeData = {
                languageCode: req.body.languageCode,
                homeCarouselSection: [
                    { 
                        carouselTitle: req.body.carouselTitle, 
                        carouselImg: `/upload/${req.file.filename}` // Multer saves filename
                    }
                ],
                homeContact: { 
                    title: req.body.title,
                    animatedText: req.body.animatedText,
                    company: req.body.company,
                    mobile: req.body.mobile,
                    email: req.body.email,
                    address: req.body.address,
                    btn: req.body.btn,
                },
            };
    
            // Create a new home entry
            const home = new Home(homeData);
            const savedHome = await home.save();
    
            // Send success response
            commonResponse.success(
                res, 
                "Home Created Successfully", 
                201, 
                savedHome, 
                "Success"
            );
        } catch (error) {
            next(error);
        }
    },
    
    
    /**
     * List
     */
    listHome: async (req, res, next) => {
        try {
            // Log the request headers to ensure the languageCode is being sent and received correctly
            console.log("Request Headers: ", req.headers);
    
            // Get the languageCode from the request headers, default to 'vn' if not provided
            const languageCode = req.headers['languagecode'] || 'vn';  // Ensure lowercase
    
            // Log the selected language code for debugging
            console.log("Selected languageCode: ", languageCode);
    
            // Create query to filter by languageCode and deletedAt
            let query = { deletedAt: null, languageCode: languageCode };
    
            // Fetch the data based on the query
            let listAll = await Home.find(query);
    
            // Check if there is data for the specified language
            if (listAll.length > 0) {
                commonResponse.success(res, "Homes Retrieved Successfully", 200, listAll, "Success");
            } else {
                commonResponse.customResponse(res, "No Homes Found", 404, {}, "No data available");
            }
        } catch (error) {
            // Handle any errors that occur
            commonResponse.error(res, "Internal Server Error", 500, error.message);
        }
    },
    
    
    
    /**
     * Get
     */

    getHome: async (req, res, next) => {
        try {
            if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
                return commonResponse.error(res, "Invalid ID format", 400, "Invalid ID format");
            }
            const home = await Home.findById(req.params.id);
            if (!home) return res.status(404).json({ message: "Home Section Not Found" });
            commonResponse.success(res, "Home Retrieved Successfully", 200, home, "Success");
        } catch (error) {
            commonResponse.error(res, "Internal Server Error", 500, error.message);
        }
    },

    /**
     * Update
     */

    updateHome: async (req, res, next) => {
        try {
            if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
                return commonResponse.error(res, "Invalid ID format", 400, "Invalid ID format");
            }
            const updateData = {
                ...req.body,
            };
    
            // If a new file is uploaded, update the carouselImg
            if (req.file) {
                updateData.homeCarouselSection = [{ 
                    carouselTitle: req.body.carouselTitle, 
                    carouselImg: `/uploads/${req.file.filename}` 
                }];
            }
    
            const home = await Home.findByIdAndUpdate(req.params.id, updateData, { new: true });
            if (!home) return commonResponse.customResponse(res, "Home Section Not Found", 404, {}, "Not found");
            commonResponse.success(res, "Home Updated Successfully", 200, home, "Success");
        } catch (error) {
            commonResponse.error(res, "Internal Server Error", 500, error.message);
        }
    },

    /**
     * delete
     */

    deleteHome: async (req, res, next) => {
        try {
            if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
                return commonResponse.error(res, "Invalid ID format", 400, "Invalid ID format");
            }
    
            const home = await Home.findById(req.params.id);
    
            if (!home) return res.status(404).json({ message: "Home Section Not Found" });
    
                home.deletedAt = new Date();
            await home.save();
    
            res.json({ message: "Home Section Soft Deleted" });
        } catch (error) {
            next(error);
        }
    }
    
};

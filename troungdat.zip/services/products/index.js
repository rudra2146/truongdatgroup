const productsRoutes = require('./products.routes');


module.exports = productsRoutes;


module.exports = {
  apps: [
    {
      name: 'rudra',
      script: './bin/www',
      watch: true,
      env: {
        NODE_ENV: 'development',
        MONGO_URI :"mongodb://localhost:27017/products",
        JWT_SECRET: 'rudra123', 
        GMAIL_USER: 'viralpandya079@gmail.com',
        GMAIL_PASS: 'tqxagvltwtgxvali'
      },
      env_local: {
        NODE_ENV: 'local',
        JWT_SECRET: 'rudra123'
      }
    }
  ]
};
      